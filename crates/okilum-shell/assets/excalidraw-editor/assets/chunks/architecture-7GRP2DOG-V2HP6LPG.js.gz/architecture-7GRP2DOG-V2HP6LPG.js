import{a as e,b as r}from"./chunk-CZ35GS7P.js";import"./chunk-DEF4ZZIA.js";import"./chunk-SU2Z73VX.js";export{e as ArchitectureModule,r as createArchitectureServices};
