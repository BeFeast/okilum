import{a as e,b as r}from"./chunk-AWL3C5AS.js";import"./chunk-DEF4ZZIA.js";import"./chunk-SU2Z73VX.js";export{e as PacketModule,r as createPacketServices};
