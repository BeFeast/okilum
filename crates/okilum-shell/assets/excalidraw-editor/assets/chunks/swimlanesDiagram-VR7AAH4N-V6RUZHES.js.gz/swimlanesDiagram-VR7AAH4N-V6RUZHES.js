import{a as o,b as e}from"./chunk-MFPBPIWQ.js";import"./chunk-EXZCZFP2.js";import"./chunk-NBH7YOBD.js";import"./chunk-5FZCLUCJ.js";import"./chunk-PRLHC3YS.js";import"./chunk-WJQUEJOP.js";import"./chunk-VB4LO2JO.js";import"./chunk-CRVHWQ3Z.js";import"./chunk-ZSOA6NP7.js";import"./chunk-5LD4KHE5.js";import"./chunk-EJXTPAZB.js";import"./chunk-B6DLVZHA.js";import"./chunk-P3HYAAVJ.js";import"./chunk-7XGWXFK5.js";import"./chunk-CSA2MKSM.js";import"./chunk-AOX4GSIV.js";import"./chunk-VHJCIHKZ.js";import"./chunk-Q6JCIQN2.js";import"./chunk-JPGNKPDP.js";import{a as r}from"./chunk-EIBFAW37.js";import"./chunk-SU2Z73VX.js";var m=r(t=>`${o(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,"getStyles"),i=m,B=e({defaultLayout:"swimlane",styles:i});export{B as diagram};
