---
type: Note
---

# Offline capture boundary

A future mobile thought can wait locally until connected.

## Current alpha

Desktop capture only. Mobile delivery remains a proposal.
