---
type: Goal
---

# Document the offline capture boundary

Synthetic goal; state: blocked.
